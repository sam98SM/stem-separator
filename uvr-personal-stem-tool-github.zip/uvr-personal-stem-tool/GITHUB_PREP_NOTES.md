# GitHub preparation notes

This copy was prepared from the uploaded Ultimate Vocal Remover GUI source archive for personal use.

Changes made only for repository hygiene:
- Added `.gitignore` for Python caches, local audio, generated exports, secrets, and downloaded model weights.
- Removed the bundled `models/VR_Models/UVR-DeNoise-Lite.pth` weight from this prepared copy so model binaries are not committed by default.
- No source-code behavior was changed.

Important licensing note:
The uploaded README states that Ultimate Vocal Remover GUI code is MIT-licensed and links to a `LICENSE` file, but that `LICENSE` file was not present in the uploaded archive. Verify the upstream project's licensing files and the license/terms of each model weight before redistributing them.
